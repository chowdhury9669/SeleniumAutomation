package test.economictimes;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.economictime.common.Configuration;
import com.economictime.common.StartDriver;
import com.economictime.module.Login;
import com.relevantcodes.extentreports.LogStatus;

public class SignIn extends  StartDriver{
	
	
	public SignIn(){
		super();
	}
	


	private  Login user;
	
	
	//Test case  User is login with successfully with valid  user id and password
	 
	
	@Test
	@Parameters({"userName","Password"})
	public void TC_002(String userName,String Password) throws Exception{
		
		
		Test = report.startTest("Login   TC_002");
		// String TestcaseShet=Configuration.testCaesSheetLocation;
		 user = new Login(super.webDriver, super.URL);
		boolean result= user.logInLogoutTraditionalWay(userName,Password);
		
		if(result) {
			Test.log(LogStatus.PASS, "User is able to login successfuly with valid user id and password");
				
			
		}
		else {
			
			Test.log(LogStatus.FAIL, "User is not  able to login successfuly with valid user id and password");
		}
		
	
	}

	//Test case 1 User registration successfully with valid  details
	
	@Test
	@Parameters({"emailId","firstName","password","mobNo"})
	
public void TC_001(String emailId, String firstName,String password,String mobNo) throws IOException {
		
		 user = new Login(super.webDriver, super.URL);
		 boolean result = user.signUp(emailId, firstName, password, mobNo);
		 Test = report.startTest("Login   TC_001");
		 
		 if(result) {
			 Test.log(LogStatus.PASS, "User is able to Register ");
			 
		 }
		 else {
			 Test.log(LogStatus.PASS, "User is not  able to Register ");
			 
		 }
		 report.endTest(Test);
			
	}
	/// test case 3 user is sigin in with GOOGLE++
	@Test
	@Parameters({"userID","password"})
	public void TC_003(String userID ,String password) throws IOException {
		 user = new Login(super.webDriver, super.URL);
		 Test = report.startTest("Login   TC_003");
		boolean rs=user.logIOutBySocail(userID, password);
		
		if(rs) {
			 Test.log(LogStatus.PASS, "User is able to Register ");
			 
		 }
		 else {
			 Test.log(LogStatus.FAIL, "User is not  able to Register ");
			 
		 }
		 report.endTest(Test);
		 
		
	}
	
	
	// with invalid user id password
	@Test
	@Parameters({"userName","Password"})
	public void TC_004(String userName,String Password) throws Exception{
		
		
		Test = report.startTest("Login   TC_004");
		// String TestcaseShet=Configuration.testCaesSheetLocation;
		 user = new Login(super.webDriver, super.URL);
		boolean result= user.logInLogoutTraditionalWay(userName,Password);
		
		if(result==false) {
			
				
			Test.log(LogStatus.PASS, "User is able to login successfuly with valid user id and password");
		}
		else {
			
			
			
			Test.log(LogStatus.FAIL, "User is not  able to login successfuly with valid user id and password");
		}
		report.endTest(Test);	
	
		report.flush();
		String Url=Configuration.reportLocation;
		File htmlFile = new File(Url);		
	
		Desktop.getDesktop().browse(htmlFile.toURI());

	
	}
	
	
	
}
