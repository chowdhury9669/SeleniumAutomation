package test.economictimes;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;


import com.economictime.common.StartDriver;

import com.economictime.module.SearchCapabalities;
import com.relevantcodes.extentreports.LogStatus;

public class Search extends  StartDriver{
	public Search(){
		super();
	}
		
		private  SearchCapabalities sc1;
		@Test
		@Parameters({"userName","Password","word"})
		
		public void TC_001(String userName,String Password,String word ) throws Exception{
			// String TestcaseShet=Configuration.testCaesSheetLocation;
			
			Test = report.startTest("SearchCapabalities   TC_001");
			
			sc1 = new SearchCapabalities(super.webDriver, super.URL);
			 
			 
boolean a=sc1.afterLoginScearch(userName,Password,word);

if (a) {
	 Test.log(LogStatus.PASS, "User is able to scearch after succesfully login to the site ");
}
else {
	 Test.log(LogStatus.FAIL, "User is able not  to scearch after succesfully login to the site ");
}
report.endTest(Test);
}
		
}