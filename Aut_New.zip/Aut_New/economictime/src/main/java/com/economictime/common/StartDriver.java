package com.economictime.common;

import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;





public class StartDriver {

	protected static Properties config;	
	protected String URL=null;
	protected WebDriver webDriver;
	protected WebElement webelement;
	private DriverFactory factory;
	public static ExtentReports report;
	public  static ExtentTest Test;
	public String getURL(){
		return URL;
	}
	
	public StartDriver() {
		
		Configuration cnfg = new Configuration();
		cnfg.intilizeProjectConfigProprty();
		report = new ExtentReports (Configuration.reportLocation,true);
		 
	}
	
	@BeforeClass
	@Parameters({"browsername","url"})
	public WebDriver intilizeDriver(String browsername,String url){
		
		
		factory= new DriverFactory();
		webDriver= factory.getDriver(browsername);
		this.URL = url;
	return webDriver;
	}
	
	@AfterClass
	public void quiteDriver() 
	{	
		
			webDriver.close();
			webDriver.quit();
			
		}

}
