package com.economictime.common;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

import java.util.Properties;

public class Configuration {
	
	public static String IE_browseLocation;
	public static String FF_browseLocation;
	public static String Chrome_browserLocation;
	public static String reportLocation;
	public static String testCaesSheetLocation;
	public static String ScreenShots;
    private static Properties prop;
    
    public Configuration(){
    	try {
    		prop = new Properties();
    		prop.load(new FileInputStream(System.getProperty("user.dir").concat("\\src\\report\\configuration.properties")));
		} catch (FileNotFoundException e) {
		
			System.out.println("configurationFile is not found"+e.getMessage());
			
		} catch (Exception e) {
				
			System.out.println("Some error occured at configuration constructer");
    	
    }
	
    }
    
    public  void intilizeProjectConfigProprty () {
		try {
			

		
			Chrome_browserLocation=prop.getProperty("chrome_driver");
		IE_browseLocation=prop.getProperty("iE_Driver");
		FF_browseLocation=prop.getProperty("fireFox");
		testCaesSheetLocation=prop.getProperty("Test_Case_Sheet");
		reportLocation=prop.getProperty("report_location");
		ScreenShots=prop.getProperty("ScreenShotsStorageLocation");
		
		
		

		
		} catch (Exception e) {
			
			System.out.println("Some error occured at intilizeProjectConfigProprty"+e.getMessage());
		}
		
	
	}
	
	
}
