package com.economictime.module;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.economictime.common.Base;

public class Login extends Base {
	
	public Login(WebDriver driver, String url){
		super(driver,url);
	}

	public boolean logInLogoutTraditionalWay(String userID,String password){
		boolean result=false;
		
		try {
			
			webDriver.get(url);
			
			webDriver.findElement(By.xpath(	signUpIn.getProperty("click_on_sognin_Home"))).click();
			Thread.sleep(5000);
			SwitchWindow();
			Thread.sleep(5000);
			webDriver.findElement(By.xpath(signUpIn.getProperty("enter_id"))).sendKeys(userID);
			Thread.sleep(5000);
			webElement = webDriver.findElement(By.xpath(signUpIn.getProperty("click_SignIn")));
			
			if (webElement.isEnabled()) {
				webElement.click();
				Thread.sleep(5000);
				webElement = webDriver.findElement(By.xpath(signUpIn.getProperty("enter_Tpassword")));
				webElement.sendKeys(password);
				Thread.sleep(5000);
				webElement = webDriver.findElement(By.xpath(signUpIn.getProperty("click_cnfSignIn")));
				webElement.click();
				
				Thread.sleep(2000);
				
				//SwitchWindow();
				Thread.sleep(2000);
				result = true; 
				
				
			}
			
			else {
				
				System.out.println("click_SignIn is not enabled");
				result=false;
			
			}
		
		} catch (InterruptedException e) {
		
			System.out.println("some error occured logInLogoutTraditionalWay method");
			result=false;
		}
	
		return result;
		
	}

public boolean logIOutBySocail(String UserID,String Password) {
	
	boolean result =false;
	
	try {
		webDriver.get(url);
		webDriver.findElement(By.xpath(	signUpIn.getProperty("click_on_sognin_Home"))).click();
		Thread.sleep(5000);
		SwitchWindow();
		Thread.sleep(5000);
		webElement=webDriver.findElement(By.xpath(signUpIn.getProperty("click_on_social_Google")));
		webElement.click();
		
		SwitchWindow();
		/* String handle = webDriver.getWindowHandles().toArray()[2].toString();
		 webDriver.switchTo().window(handle);*/
		Thread.sleep(5000);
		webElement=webDriver.findElement(By.xpath(signUpIn.getProperty("enter_GmailID")));
		webElement.sendKeys(UserID);
		Thread.sleep(5000);	
	webElement=webDriver.findElement(By.xpath(signUpIn.getProperty("click_next")));
		webElement.click();
		Thread.sleep(5000);
		webElement=webDriver.findElement(By.xpath(signUpIn.getProperty("enter_password")));
		webElement.sendKeys(Password);
		Thread.sleep(5000);
		webElement=webDriver.findElement(By.xpath(signUpIn.getProperty("click_next_password")));
		webElement.click();
		SwitchWindow();
		Thread.sleep(2000);
		
		result =true;
		
	} catch (InterruptedException e) {
		System.out.println("some error occured logInLogoutTraditionalWay method"+e.getMessage());
	
	result =false; 
	}
	return result;
	
	
}


public boolean signUp(String emailId, String firstName,String password,String mobNo) {

	
	
	boolean result=false;
	try {
		
		
		webDriver.get(url);
		
		webDriver.findElement(By.xpath(	signUpIn.getProperty("click_on_sognin_Home"))).click();
		Thread.sleep(5000);
		SwitchWindow();
		
		//webDriver.manage().window().maximize();
		Thread.sleep(5000);
		webDriver.findElement(By.xpath(signUpIn.getProperty("enter_id"))).sendKeys(emailId);
		
		Thread.sleep(5000);
		webElement = webDriver.findElement(By.xpath(signUpIn.getProperty("click_SignIn")));
		if (webElement.isEnabled()) {
			webElement.click();
			Thread.sleep(5000);
			webElement = webDriver.findElement(By.xpath(signUpIn.getProperty("enter_firstName")));
			webElement.sendKeys(firstName);
			Thread.sleep(5000);
			webElement = webDriver.findElement(By.xpath(signUpIn.getProperty("enter_Tpassword")));
			webElement.sendKeys(password);
			 	 
			Thread.sleep(5000);
			webElement = webDriver.findElement(By.xpath(signUpIn.getProperty("enter_confirmed_password")));
			webElement.sendKeys(password);
		
			Thread.sleep(5000);
			webElement = webDriver.findElement(By.xpath(signUpIn.getProperty("enter_mobileNo")));
			webElement.sendKeys(mobNo);
			Thread.sleep(5000);
			webElement = webDriver.findElement(By.xpath(signUpIn.getProperty("enter_upload")));
			webElement.click();
			Thread.sleep(5000);
			SwitchWindow();
			Thread.sleep(2000);
			result=true;
		}
		
		else {
			
			System.out.println("click_SignIn is not enabled");
		
			result=false;
		}
	
	} catch (InterruptedException e) {
		result=false;
		System.out.println("Some error occured at signUp "+e.getMessage());
	}
	
return result;
}

}
