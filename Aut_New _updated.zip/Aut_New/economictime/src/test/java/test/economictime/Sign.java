package test.economictime;

import com.economictime.common.StartDriver;

public class Sign extends StartDriver {
	
	

}
