package com.economictime.common;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

public class DriverFactory {
	
	private WebDriver webDriver;
	private String BrowserDetails=null;
	public DriverFactory() 
	{
		 
	}
	
	
	public WebDriver getDriver(String browserName){
		try{
		if(browserName.equalsIgnoreCase(Constraints.IE_BROWSER)){
			
			
		
			
			System.setProperty("webdriver.ie.driver",Configuration.IE_browseLocation);
			
			
			webDriver= new InternetExplorerDriver();
			BrowserDetails=Constraints.IE_BROWSER;
			}
		else if(browserName.equalsIgnoreCase(Constraints.CHROME_BROWSER)){
			
			
			
			System.setProperty("webdriver.chrome.driver",Configuration.Chrome_browserLocation);
			
			DesiredCapabilities capabilities = DesiredCapabilities.chrome();
			ChromeOptions options = new ChromeOptions();
			options.addArguments("incognito");
			options.addArguments("--start-maximized");
			options.addArguments("--disable-extensions");
			capabilities.setCapability(ChromeOptions.CAPABILITY, options);
			
			capabilities.setCapability(CapabilityType.ForSeleniumServer.ENSURING_CLEAN_SESSION, true);

		  webDriver= new ChromeDriver(capabilities);
		  
		  BrowserDetails=Constraints.CHROME_BROWSER;
		  
		}else if(browserName.equalsIgnoreCase(Constraints.FF_BROWSER)){
System.setProperty("webdriver.gecko.driver",Configuration.FF_browseLocation);
			
			webDriver= new FirefoxDriver();
			BrowserDetails= Constraints.FF_BROWSER;
			
		}
		else{
			System.setProperty("webdriver.gecko.driver",Configuration.FF_browseLocation);
			
			webDriver= new FirefoxDriver();
			BrowserDetails= Constraints.FF_BROWSER;
			
		}
		}
		catch(Exception a){
			System.out.println("Some Exception occured at DriverFActoryClass"+a.getMessage());
		}
		return webDriver;
	}
	
	public String getBrowser(){
		return BrowserDetails;
		
		
	}

	

}
