package com.economictime.common;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Base {
	
	protected WebDriver webDriver;
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public WebElement getWebelement() {
		return webElement;
	}
	public void setWebelement(WebElement webelement) {
		this.webElement = webelement;
	}
	public WebDriver getWebDriver() {
		return webDriver;
	}
	public void setWebDriver(WebDriver webDriver) {
		this.webDriver = webDriver;
	}
	protected String url;
	protected WebElement webElement;

	protected Properties signUpIn;
	protected Properties searchCapabalities;
	protected Properties actionsOnTheScreen;
	

	public Base(WebDriver webDriver,String url){
		setWebDriver(webDriver);
		setUrl(url);
		initilize();
		
	}
	public void initilize(){
		signUpIn = new Properties();
		searchCapabalities=new Properties();
		try {
			
			signUpIn.load(new FileInputStream(System.getProperty("user.dir").concat("/src/test/java/test/economictimes/SignInUp.properties")));			
				
			searchCapabalities.load(new FileInputStream(System.getProperty("user.dir").concat("/src/test/java/test/economictimes/SearchCapabalities.properties")));
		
		
		
		
		
		
		} catch (FileNotFoundException e) {
			System.out.println("Error occured in initilize method");
			System.out.println(e.getMessage());
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Error occured in initilize method");
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		
	}

///////////////////////////////////////////////////////
	
	public  void SwitchWindow() {
		for (String windowName : webDriver.getWindowHandles()) {
			webDriver.switchTo().window(windowName);
		}
	}
	

}
