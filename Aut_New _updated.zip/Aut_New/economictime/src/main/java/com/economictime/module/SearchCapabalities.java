package com.economictime.module;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import com.economictime.common.Base;

public class SearchCapabalities extends Base {

	public SearchCapabalities(WebDriver webDriver, String url) {
		super(webDriver, url);
		
	}
public boolean afterLoginScearch(String userID,String password,String word) {
	boolean result=false;
	
	try {
		Login login = new Login(super.webDriver,url);
		boolean signin =login.logInLogoutTraditionalWay(userID, password);
		if(signin) {
			SwitchWindow();
			Thread.sleep(4000);	
			webElement = webDriver.findElement(By.xpath(searchCapabalities.getProperty("login_scearch")));
			
			webElement.sendKeys(word);
		Thread.sleep(4000);
		webElement = webDriver.findElement(By.xpath(searchCapabalities.getProperty("scearch_icon")));
		webElement.click();
		Thread.sleep(4000);
		/*List <WebElement> elements = webDriver.findElements(By.tagName("a"));
		String ref= elements.get(20).getText();
		Thread.sleep(4000);
		webDriver.findElement(By.linkText(ref)).click();;
		Thread.sleep(4000);
*/		
result = true;
			
		}else {
			System.out.println("user is not sign in ");
			result=false;	
		
		}
		
		
		
		
	} catch (Exception e) {
		
	}
	return result;
	
	
}

public boolean scearchByDropDown(String word) {
	boolean result =false;
	try {
		webDriver.get(url);
		Thread.sleep(4000);	
		webElement = webDriver.findElement(By.xpath(searchCapabalities.getProperty("login_scearch")));
		webElement.sendKeys(word);
		Thread.sleep(4000);
		webElement = webDriver.findElement(By.xpath(searchCapabalities.getProperty("list_one")));
		Thread.sleep(4000);
		webElement.click();
		Thread.sleep(4000);
		
		webDriver.manage().timeouts().implicitlyWait(50000, TimeUnit.MINUTES);
		
		result = true;
	} catch (Exception e) {
		// TODO: handle exception
	
	result =false;
	}
	return result;
}
	
	
	
	
}
